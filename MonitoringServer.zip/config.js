const config = {
    process: {
        requestTimeOut: 5000
        , checkInterval: 15000
    }
    , dev : {
        nateOnWebHook: 'https://teamroom.nate.com/api/webhook/0c062513/D4eISxiRnLFGs3BD72fuXzSF'
        , notificationBaseValue: 2
        , serverList: [
            { type: 'API_AND_DATABASE', url: 'https://devapi2.dalbitlive.com/socket/dbCheck/bySocket', fail: false, failCount: 0, min: 0, max: 0 }
            , { type: 'API_AND_DATABASE', url: 'http://wadmin2.inforex.co.kr/socket/dbCheck/bySocket', fail: false, failCount: 0, min: 0, max: 0 }
            , { type: 'API_AND_DATABASE', url: 'https://devphoto2.dalbitlive.com/socket/dbCheck/bySocket', fail: false, failCount: 0, min: 0, max: 0 }
            , { type: 'API_AND_DATABASE', url: 'https://devpay2.dalbitlive.com/socket/dbCheck/bySocket', fail: false, failCount: 0, min: 0, max: 0 }
            , { type: 'HEALTH_CHECK', url: 'https://devapi2.dalbitlive.com/ctrl/check/service', fail: false, failCount: 0, min: 0, max: 0 }
            , { type: 'HEALTH_CHECK', url: 'https://devpay2.dalbitlive.com/ctrl/check/service', fail: false, failCount: 0, min: 0, max: 0 }
            , { type: 'HEALTH_CHECK', url: 'https://devphoto2.dalbitlive.com/ctrl/check/service', fail: false, failCount: 0, min: 0, max: 0 }
            , { type: 'HEALTH_CHECK', url: 'https://devm2.dalbitlive.com/ctrl/check/service', fail: false, failCount: 0, min: 0, max: 0 }
            , { type: 'HEALTH_CHECK', url: 'https://devwww2.dalbitlive.com/ctrl/check/service', fail: false, failCount: 0, min: 0, max: 0 }
        ]
    }
    , live : {
        nateOnWebHook: 'https://teamroom.nate.com/api/webhook/0c062513/xzLUzzXo86RCNk1hUHul3GsM'
        , notificationBaseValue: 2
        , serverList: [
            { type: 'API_AND_DATABASE', url: 'https://api.dalbitlive.com/socket/dbCheck/bySocket', fail: false, failCount: 0, min: 0, max: 0 }
            , { type: 'API_AND_DATABASE', url: 'http://dalbit.inforex.co.kr/socket/dbCheck/bySocket', fail: false, failCount: 0, min: 0, max: 0 }
            , { type: 'SOCKET', url: 'https://sv163.dalbitlive.com:8000/health-check', fail: false, failCount: 0, min: 0, max: 0 }
            , { type: 'SOCKET', url: 'https://sv164.dalbitlive.com:8000/health-check', fail: false, failCount: 0, min: 0, max: 0 }
            , { type: 'HEALTH_CHECK', url: 'https://api.dalbitlive.com/ctrl/check/service', fail: false, failCount: 0, min: 0, max: 0 }
        ]
    }
    /*    
    , database: {
        host: '125.141.223.157'
        , user: 'inforex'
        , password: 'inforex'
        , database: 'rd_data'
        , dateStrings: 'date'
        , port: 13306
        , multipleStatements: true
    }
    , smsTargetList: [
        { MSG_TYPE: 0, SEND_PHONE: '1522-0251', DEST_PHONE: '010-2049-1354', SUBJECT: 'API 체크', MSG_BODY: '응답이 느립니다.', VXML_FILE: '99' }
    ]*/
};

exports.config = config;